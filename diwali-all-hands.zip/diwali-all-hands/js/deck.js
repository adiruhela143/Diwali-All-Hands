/* The Manifest Bahi-Khata — presentation engine (Reveal.js + GSAP) */
(function () {
  'use strict';

  var REDUCED = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var slides = Array.prototype.slice.call(document.querySelectorAll('.reveal .slides > section'));

  /* ---------------------------------------------------------------- Diyas */
  var svgDefs = document.createElement('div');
  svgDefs.style.cssText = 'position:absolute;width:0;height:0;overflow:hidden';
  svgDefs.innerHTML = '<svg aria-hidden="true"><defs><radialGradient id="diyaGlow"><stop offset="0" stop-color="#FDDC72" stop-opacity=".9"/><stop offset=".55" stop-color="#FDDC72" stop-opacity=".25"/><stop offset="1" stop-color="#FDDC72" stop-opacity="0"/></radialGradient></defs></svg>';
  document.body.appendChild(svgDefs);

  function diyaSVG(lit) {
    return '<svg class="diya' + (lit ? ' lit' : '') + '" viewBox="0 0 66 92" aria-hidden="true">' +
      '<g class="fwrap">' +
        '<circle class="glow" cx="33" cy="34" r="30" fill="url(#diyaGlow)"/>' +
        '<g class="flame">' +
          '<path d="M33 2C42 16 49 30 45 43C42 54 24 54 21 43C17 30 24 16 33 2Z" fill="#FDDC72"/>' +
          '<path d="M33 20C37.5 28 40 35 38.5 42C37 48 29 48 27.5 42C26 35 28.5 28 33 20Z" fill="#F05A47"/>' +
        '</g>' +
      '</g>' +
      '<path class="bowl" d="M2 58Q33 62.5 64 58Q58 86 33 86Q8 86 2 58Z"/>' +
    '</svg>';
  }
  function diyaRow(n) { var h = ''; for (var i = 1; i <= 5; i++) h += diyaSVG(i <= n); return h; }

  document.querySelectorAll('.diyas').forEach(function (row) { row.innerHTML = diyaRow(+row.dataset.lit || 0); });

  /* ------------------------------------------------- Chrome: corner + footer */
  slides.forEach(function (s) {
    if (!s.classList.contains('std')) return;
    var onRed = s.classList.contains('on-red');
    if (!onRed) {
    var corner = document.createElement('div');
    corner.className = 'corner';
    corner.setAttribute('aria-hidden', 'true');
    corner.innerHTML = '<i></i><i></i><i></i>';
    s.insertBefore(corner, s.firstChild);
    }
    var foot = document.createElement('footer');
    foot.className = 'foot';
    foot.innerHTML = '<span class="ft-text">Manifest.inc | Diwali All Hands 2026</span>' +
      '<span class="ft-right"><span class="ft-diyas" title="Diyas lit so far">' + diyaRow(+s.dataset.lit || 0) + '</span>' +
      '<img class="ft-logo" src="assets/img/' + (onRed ? 'manifest-logo-onred.png' : 'manifest-logo.png') + '" alt="Manifest Global"></span>';
    var notes = s.querySelector('aside.notes');
    s.insertBefore(foot, notes);
  });

  /* ------------------------------------------------------ Split headlines */
  function splitNode(node) {
    Array.prototype.slice.call(node.childNodes).forEach(function (n) {
      if (n.nodeType === 3) {
        var frag = document.createDocumentFragment();
        n.textContent.split(/(\s+)/).forEach(function (part) {
          if (!part) return;
          if (/^\s+$/.test(part)) { frag.appendChild(document.createTextNode(part)); return; }
          var w = document.createElement('span'); w.className = 'w';
          var wi = document.createElement('span'); wi.className = 'wi'; wi.textContent = part;
          w.appendChild(wi); frag.appendChild(w);
        });
        n.parentNode.replaceChild(frag, n);
      } else if (n.nodeType === 1 && n.tagName !== 'BR') {
        splitNode(n);
      }
    });
  }
  document.querySelectorAll('.split').forEach(splitNode);

  /* ------------------------------------------------------------ Chart */
  document.querySelectorAll('[data-chart]').forEach(function (c) {
    var bars = c.querySelectorAll('.bar');
    var max = 0;
    bars.forEach(function (b) { max = Math.max(max, +b.dataset.v); });
    bars.forEach(function (b) { b.style.height = Math.max(3, Math.round(+b.dataset.v / max * 132)) + 'px'; });
    c.querySelectorAll('.v').forEach(function (v) { v.setAttribute('data-count', ''); });
  });

  /* ---------------------------------------------------------- Count-ups */
  document.querySelectorAll('[data-count]').forEach(function (el) {
    var m = el.textContent.trim().match(/^([^\d]*)([\d,]+(?:\.\d+)?)(.*)$/);
    if (!m) return;
    el.dataset.orig = el.textContent.trim();
    el.dataset.pre = m[1]; el.dataset.num = m[2].replace(/,/g, ''); el.dataset.suf = m[3];
    el.style.fontVariantNumeric = 'tabular-nums';
  });
  function fmt(n) { return Math.round(n).toLocaleString('en-US'); }
  function countTween(tl, els, at, dur) {
    els.forEach(function (el, i) {
      if (!el.dataset.num) return;
      var o = { v: 0 }, target = +el.dataset.num;
      tl.fromTo(o, { v: 0 }, {
        v: target, duration: dur || 1.6, ease: 'power2.out',
        onStart: function () { el.textContent = el.dataset.pre + '0' + el.dataset.suf; },
        onUpdate: function () { el.textContent = el.dataset.pre + fmt(o.v) + el.dataset.suf; },
        onComplete: function () { el.textContent = el.dataset.orig; }
      }, at + i * 0.08);
    });
  }

  /* ------------------------------------------------- Entrance timelines */
  var timelines = new WeakMap();

  function ignite(tl, svg, at) {
    var wrap = svg.querySelector('.fwrap');
    tl.call(function () { svg.classList.add('lit'); }, null, at);
    tl.fromTo(wrap, { scale: 0, opacity: 0, transformOrigin: '50% 100%' },
      { scale: 1, opacity: 1, duration: 0.9, ease: 'back.out(2.2)' }, at);
  }

  function build(slide) {
    var tl = gsap.timeline({ defaults: { ease: 'power3.out' }, paused: true });
    var $ = function (sel) { return Array.prototype.slice.call(slide.querySelectorAll(sel)); };
    var notInFragment = function (el) { return !el.closest('.fragment'); };

    // Corner bars
    var corner = $('.corner i');
    if (corner.length) tl.fromTo(corner, { scaleX: 0 }, { scaleX: 1, duration: 1.1, stagger: 0.09, ease: 'expo.out' }, 0);

    // Kicker
    var kicker = slide.querySelector('.kicker');
    if (kicker) tl.fromTo(kicker, { autoAlpha: 0, x: -14 }, { autoAlpha: 1, x: 0, duration: 0.8 }, 0.05);

    // Headline word masks
    var words = $('.split .wi');
    if (words.length) tl.fromTo(words, { yPercent: 115 }, { yPercent: 0, duration: 1, stagger: 0.035, ease: 'expo.out' }, 0.12);

    // Day divider: mandala + number + diyas
    if (slide.classList.contains('day')) {
      var wrap = slide.querySelector('.mandala-wrap');
      tl.fromTo(wrap, { autoAlpha: 0, scale: 0.8, rotation: -50 }, { autoAlpha: 1, scale: 1, rotation: 0, duration: 1.8, ease: 'expo.out' }, 0.05);
      tl.fromTo(slide.querySelector('.day-num'), { autoAlpha: 0, scale: 0.5 }, { autoAlpha: 1, scale: 1, duration: 1.1, ease: 'back.out(1.7)' }, 0.55);
    }

    // Diya rows
    $('.diyas').forEach(function (row) {
      var lit = +row.dataset.lit || 0;
      var svgs = Array.prototype.slice.call(row.querySelectorAll('.diya'));
      tl.fromTo(svgs, { autoAlpha: 0, y: 14 }, { autoAlpha: 1, y: 0, duration: 0.6, stagger: 0.07 }, 0.45);
      if (slide.classList.contains('day')) {
        svgs.forEach(function (s, i) { if (i === lit - 1) s.classList.remove('lit'); });
        ignite(tl, svgs[lit - 1], 1.35);
      } else {
        // closing slide: light every diya in turn
        svgs.forEach(function (s) { s.classList.remove('lit'); });
        svgs.slice(0, lit).forEach(function (s, i) { ignite(tl, s, 1.1 + i * 0.32); });
      }
    });

    // Generic [data-a] elements in reading order
    var t = 0.4;
    $('[data-a]').filter(notInFragment).forEach(function (el) {
      var type = el.dataset.a;
      if (type === 'bar') return; // handled below
      if (type === 'up') { tl.fromTo(el, { autoAlpha: 0, y: 26 }, { autoAlpha: 1, y: 0, duration: 0.9 }, t); t += 0.1; }
      else if (type === 'fade') { tl.fromTo(el, { autoAlpha: 0 }, { autoAlpha: 1, duration: 0.9, ease: 'power1.out' }, t); t += 0.06; }
      else if (type === 'left') { tl.fromTo(el, { autoAlpha: 0, x: -40 }, { autoAlpha: 1, x: 0, duration: 1 }, t); t += 0.12; }
      else if (type === 'scale') { tl.fromTo(el, { autoAlpha: 0, scale: 0.88, transformOrigin: '0% 60%' }, { autoAlpha: 1, scale: 1, duration: 1.1, ease: 'expo.out' }, t); t += 0.12; }
      else if (type === 'rise') { tl.fromTo(el, { autoAlpha: 0, y: 70 }, { autoAlpha: 1, y: 0, duration: 1.4, ease: 'expo.out' }, t); t += 0.12; }
      else if (type === 'reveal-r') {
        tl.fromTo(el, { clipPath: 'inset(0% 0% 0% 100%)' }, { clipPath: 'inset(0% 0% 0% 0%)', duration: 1.5, ease: 'expo.inOut' }, 0);
        var img = el.querySelector('img');
        if (img) tl.fromTo(img, { scale: 1.18 }, { scale: 1, duration: 2.4, ease: 'expo.out' }, 0.1);
      }
      else if (type === 'stagger' || type === 'stagger-pop') {
        var kids = Array.prototype.slice.call(el.children);
        var pop = type === 'stagger-pop';
        tl.fromTo(kids,
          pop ? { autoAlpha: 0, scale: 0.86, y: 8 } : { autoAlpha: 0, y: 20 },
          pop ? { autoAlpha: 1, scale: 1, y: 0, duration: 0.7, stagger: 0.035, ease: 'back.out(1.5)' }
              : { autoAlpha: 1, y: 0, duration: 0.8, stagger: 0.075 }, t);
        t += Math.min(0.6, kids.length * (pop ? 0.025 : 0.06));
      }
    });

    // Growth bars (how we earn) — rise after their columns
    var bars = $('[data-a="bar"]');
    if (bars.length) tl.fromTo(bars, { scaleY: 0, transformOrigin: '50% 100%' }, { scaleY: 1, duration: 1, stagger: 0.12, ease: 'expo.out' }, 0.9);

    // Column chart
    $('[data-chart]').forEach(function (c) {
      var cb = Array.prototype.slice.call(c.querySelectorAll('.bar'));
      var vs = Array.prototype.slice.call(c.querySelectorAll('.v'));
      tl.fromTo(cb, { scaleY: 0, transformOrigin: '50% 100%' }, { scaleY: 1, duration: 1.1, stagger: 0.08, ease: 'expo.out' }, 0.55);
      tl.fromTo(vs, { autoAlpha: 0, y: 8 }, { autoAlpha: 1, y: 0, duration: 0.5, stagger: 0.08 }, 0.75);
      countTween(tl, vs, 0.75, 1.1);
    });

    // Count-ups for headline stats (outside chart)
    var counts = $('[data-count]').filter(function (el) { return !el.closest('[data-chart]') && notInFragment(el); });
    if (counts.length) countTween(tl, counts, 0.7, 1.8);

    // Footer
    var foot = slide.querySelector('.foot');
    if (foot) tl.fromTo(foot, { autoAlpha: 0 }, { autoAlpha: 1, duration: 1 }, 0.5);

    return tl;
  }

  function play(slide, delay) {
    var old = timelines.get(slide);
    if (old) old.kill();
    var tl = build(slide);
    timelines.set(slide, tl);
    tl.progress(0);
    if (REDUCED) { tl.progress(1); return; }
    gsap.delayedCall(delay || 0, function () { if (timelines.get(slide) === tl) tl.play(); });
  }
  function finish(slide) {
    var tl = slide && timelines.get(slide);
    if (tl) tl.progress(1);
  }

  /* --------------------------------------------------- Section curtain */
  var wipe = document.getElementById('wipe');
  wipe.innerHTML = diyaSVG(true);
  function curtain() {
    if (REDUCED) return 0;
    gsap.killTweensOf(wipe);
    gsap.timeline()
      .set(wipe, { clipPath: 'inset(0% 100% 0% 0%)' })
      .to(wipe, { clipPath: 'inset(0% 0% 0% 0%)', duration: 0.5, ease: 'power3.inOut' })
      .fromTo(wipe.querySelector('.diya'), { scale: 0.6, autoAlpha: 0 }, { scale: 1, autoAlpha: 1, duration: 0.35, ease: 'back.out(2)' }, 0.25)
      .to(wipe, { clipPath: 'inset(0% 0% 0% 100%)', duration: 0.65, ease: 'power3.inOut' }, 0.75);
    return 0.85;
  }

  /* ------------------------------------------------------------ Reveal */
  Reveal.initialize({
    width: 1280,
    height: 720,
    margin: 0.035,
    minScale: 0.1,
    maxScale: 3,
    center: false,
    hash: window.DECK_HASH !== false,
    controls: false,
    progress: true,
    slideNumber: false,
    transition: 'fade',
    transitionSpeed: 'default',
    backgroundTransition: 'fade',
    overview: true,
    touch: true,
    scrollActivationWidth: null,
    view: null,
    help: true,
    pdfSeparateFragments: false,
    plugins: [RevealNotes]
  });

  var lastIndex = 0;
  Reveal.on('ready', function (e) {
    lastIndex = e.indexh;
    play(e.currentSlide, 0.15);
    updateToolbar();
    requestAnimationFrame(function () { document.documentElement.classList.remove('is-loading'); });
  });

  Reveal.on('slidechanged', function (e) {
    finish(e.previousSlide);
    var forward = e.indexh > lastIndex;
    lastIndex = e.indexh;
    var delay = 0.05;
    if (forward && e.currentSlide.classList.contains('day')) delay = curtain();
    play(e.currentSlide, delay);
    updateToolbar();
  });

  Reveal.on('fragmentshown', function (e) {
    // count-ups inside newly shown fragments
    var counts = e.fragment.querySelectorAll('[data-count]');
    if (counts.length) { var tl = gsap.timeline(); countTween(tl, Array.prototype.slice.call(counts), 0.1, 1.4); }
    updateToolbar();
  });
  Reveal.on('fragmenthidden', updateToolbar);

  Reveal.on('overviewshown', function () {
    slides.forEach(function (s) { finish(s); });
    toolbar.classList.remove('idle');
  });
  Reveal.on('overviewhidden', function () { play(Reveal.getCurrentSlide(), 0.1); });

  /* ----------------------------------------------------------- Toolbar */
  var toolbar = document.querySelector('.toolbar');
  var elCount = document.getElementById('tb-count');
  var elChapter = document.getElementById('tb-chapter');
  var bPrev = document.getElementById('tb-prev');
  var bNext = document.getElementById('tb-next');
  var bFull = document.getElementById('tb-full');

  function updateToolbar() {
    var idx = Reveal.getIndices().h + 1;
    var total = Reveal.getTotalSlides();
    elCount.innerHTML = '<b>' + idx + '</b> / ' + total;
    var cur = Reveal.getCurrentSlide();
    elChapter.textContent = (cur && cur.dataset.chapter) || '';
    bPrev.disabled = Reveal.isFirstSlide() && !Reveal.availableFragments().prev;
    bNext.disabled = Reveal.isLastSlide() && !Reveal.availableFragments().next;
  }

  bPrev.addEventListener('click', function () { Reveal.prev(); });
  bNext.addEventListener('click', function () { Reveal.next(); });
  document.getElementById('tb-overview').addEventListener('click', function () { Reveal.toggleOverview(); });
  document.getElementById('tb-notes').addEventListener('click', function () {
    var notes = Reveal.getPlugin('notes'); if (notes) notes.open();
  });

  var root = document.documentElement;
  var canFull = !!(root.requestFullscreen || root.webkitRequestFullscreen);
  if (!canFull) bFull.style.display = 'none';
  function isFull() { return document.fullscreenElement || document.webkitFullscreenElement; }
  bFull.addEventListener('click', function () {
    if (isFull()) (document.exitFullscreen || document.webkitExitFullscreen).call(document);
    else (root.requestFullscreen || root.webkitRequestFullscreen).call(root);
  });
  function fsIcon() {
    bFull.innerHTML = isFull()
      ? '<svg viewBox="0 0 24 24"><path d="M9 4v5H4M15 4v5h5M9 20v-5H4M15 20v-5h5"/></svg>'
      : '<svg viewBox="0 0 24 24"><path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/></svg>';
    bFull.setAttribute('aria-label', isFull() ? 'Exit fullscreen' : 'Fullscreen');
  }
  document.addEventListener('fullscreenchange', fsIcon);
  document.addEventListener('webkitfullscreenchange', fsIcon);

  // auto-hide toolbar while presenting; reappear on pointer activity
  var idleTimer;
  function wake() {
    toolbar.classList.remove('idle');
    clearTimeout(idleTimer);
    idleTimer = setTimeout(function () {
      if (!toolbar.matches(':hover') && !Reveal.isOverview()) toolbar.classList.add('idle');
    }, 2800);
  }
  ['mousemove', 'touchstart', 'pointerdown'].forEach(function (ev) { document.addEventListener(ev, wake, { passive: true }); });
  toolbar.addEventListener('focusin', wake);
  wake();

  var hint = document.getElementById('rotate-hint');
  hint.addEventListener('click', function () { hint.style.display = 'none'; });
})();
